package net.refractionapi.refraction.feature.config.values;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.refractionapi.refraction.feature.config.Rebuilder;
import net.refractionapi.refraction.feature.config.ReconfigValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class RList<T> extends ReconfigValue<List<ReconfigValue<T>>> {
    final Class<T> clazz;

    public RList(Class<T> clazz, String id, String comment, List<ReconfigValue<T>> original) {
        super(id, comment, original);
        this.clazz = clazz;
    }

    @Override
    public StreamCodec<ByteBuf, List<ReconfigValue<T>>> streamCodec() {
        return new StreamCodec<>() {
            @SuppressWarnings("unchecked")
            @Override
            public @NotNull List<ReconfigValue<T>> decode(@NotNull ByteBuf byteBuf) {
                var defaultValue = Rebuilder.fromRaw(clazz, "", "");
                if (defaultValue == null) throw new IllegalStateException("No factory for type " + clazz);
                var codec = defaultValue.streamCodec();
                int size = byteBuf.readInt();
                for (int i = 0; i < size; i++) {
                    var value = codec.decode(byteBuf);
                    var id = ByteBufCodecs.STRING_UTF8.decode(byteBuf);
                    var element = Rebuilder.fromRaw(clazz, id, "");
                    if (element == null) continue;
                    element.set(value);
                    get().add((ReconfigValue<T>) element);
                }
                return get();
            }

            @Override
            public void encode(@NotNull ByteBuf buf, @NotNull List<ReconfigValue<T>> reconfigValues) {
                buf.writeInt(reconfigValues.size());
                reconfigValues.forEach(element -> {
                    element.encodeValue(buf);
                    ByteBufCodecs.STRING_UTF8.encode(buf, element.getId());
                });
            }
        };
    }

    @Override
    public JsonElement element() {
        var object = new JsonObject();
        var array = new JsonArray();
        get().forEach(element -> {
            var elementObject = new JsonObject();
            elementObject.add(element.getId(), element.element());
            array.add(elementObject);
        });
        object.add(getId(), array);
        return object;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ReconfigValue<T>> fromElement(JsonElement element) {
        if (!element.isJsonObject()) return get();
        var object = element.getAsJsonObject();
        if (!object.has(getId())) return get();
        var array = object.getAsJsonArray(getId());
        get().clear();
        for (int i = 0; i < array.size(); i++) {
            var elementObject = array.get(i).getAsJsonObject();
            for (var entry : elementObject.entrySet()) {
                var id = entry.getKey();
                var valueElement = entry.getValue();
                var rawObj = Rebuilder.fromRaw(clazz, id, "");
                if (rawObj == null) continue;
                rawObj.set(rawObj.fromElement(valueElement));
                get().add((ReconfigValue<T>) rawObj);
            }
        }
        return get();
    }
}
