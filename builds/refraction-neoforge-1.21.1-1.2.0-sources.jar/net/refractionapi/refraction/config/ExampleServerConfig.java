package net.refractionapi.refraction.config;

import net.refractionapi.refraction.feature.config.values.RList;
import net.refractionapi.refraction.feature.config.values.RString;
import net.refractionapi.refraction.feature.config.Reconfig;

import java.util.List;

public class ExampleServerConfig {
    public static RString EXAMPLE_STRING;
    public static RList<String> EXAMPLE_LIST;
    public static final Reconfig EXAMPLE = Reconfig.create(builder -> {
        builder.push("Examples");
        EXAMPLE_STRING = builder.comment("An example string configuration")
                .define("example_string", "default_value");
        EXAMPLE_LIST = builder.comment("An example list of strings")
                .defineList("example_string_list", String.class, List.of("item1", "item2", "item3"));
        builder.pop();
    });
}
